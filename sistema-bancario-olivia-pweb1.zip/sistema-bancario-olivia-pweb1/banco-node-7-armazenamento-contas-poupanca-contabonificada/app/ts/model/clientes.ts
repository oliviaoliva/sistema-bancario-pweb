 class Clientes {
    private _clientes: Cliente[];
  
    constructor() {
      this._clientes = [];
    }

    inserir(cliente: Cliente): void {
      this._clientes.push(cliente);
    }
  
    remover(cpf: string): void {
      this._clientes = this._clientes.filter(cliente => cliente.cpf !== cpf);
    }

    listar(): Cliente[] {
      return this._clientes;
    }
 
    pesquisar(cpf: string): Cliente | null {
      const clienteEncontrado = this._clientes.find(cliente => cliente.cpf === cpf);
      return clienteEncontrado || null;
    }
  }