let contaController = new ContaController();
let clienteController = new ClienteController();
let clientes = new Clientes();
contaController.listar();
clienteController.listar();
const c1 = new Conta('1', 100);
const c2 = new Conta('2',200);
const c3 = new Conta ('3', 300);
const p1 = new Poupanca('5', 100);
const cb1 = new ContaBonificada('6', 0);
console.log('Conta: ' + c1.saldo);
p1.atualizarSaldoAniversario();
console.log('Poupanca: ' + p1.saldo);
cb1.creditar(100);
console.log('Conta Bonificada: ' + cb1.saldo);
const cliente1 = new Cliente('João', '123.456.789-10', c1);
const cliente2 = new Cliente('Olivia', '123456789', c2);
const cliente3 = new Cliente('Pedro', '112.223.334-45', c3);
clientes.inserir(cliente1);
clientes.inserir(cliente2);
clientes.inserir(cliente3);
console.log(clientes.listar);
clientes.remover('112.223.334-45');
console.log(clientes.listar());
console.log(clientes.pesquisar('112.223.334-45'));
// const clienteEncontrado = clientes.pesquisar('111.222.333-44');
// if (clienteEncontrado) {
//   console.log('Cliente encontrado: ' + clienteEncontrado.nome);
// } else {
//   console.log('Cliente não encontrado.');
// }